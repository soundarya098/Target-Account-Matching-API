# Target Account Matching API

## How to Run

1. Install Node.js from https://nodejs.org
2. In terminal:

```bash
cd target-account-api
npm install
npm start
```

3. Test Endpoints:
- POST /login
- GET /accounts (with Bearer token)
- POST /accounts/:id/status (with Bearer token)
