const users = [
  { username: "user1", password: "pass123" }
];

const companies = [
  { id: 1, companyName: "TechCorp", matchScore: 86, status: "Target" },
  { id: 2, companyName: "InnovateX", matchScore: 72, status: "Not Target" },
  { id: 3, companyName: "FutureSoft", matchScore: 91, status: "Target" }
];

module.exports = { users, companies };
