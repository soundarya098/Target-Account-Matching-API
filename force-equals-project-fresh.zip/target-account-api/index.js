const express = require("express");
const bodyParser = require("body-parser");
const jwt = require("jsonwebtoken");
const { users, companies } = require("./data");

const app = express();
const PORT = 3000;
const SECRET = "secretKey";

app.use(bodyParser.json());

app.post("/login", (req, res) => {
  const { username, password } = req.body;
  const user = users.find(u => u.username === username && u.password === password);
  if (user) {
    const token = jwt.sign({ username }, SECRET, { expiresIn: "1h" });
    res.json({ message: "Login successful", token });
  } else {
    res.status(401).json({ message: "Invalid credentials" });
  }
});

const authMiddleware = (req, res, next) => {
  const authHeader = req.headers.authorization;
  if (!authHeader) return res.sendStatus(401);
  const token = authHeader.split(" ")[1];
  try {
    jwt.verify(token, SECRET);
    next();
  } catch (err) {
    res.sendStatus(403);
  }
};

app.get("/accounts", authMiddleware, (req, res) => {
  res.json(companies);
});

app.post("/accounts/:id/status", authMiddleware, (req, res) => {
  const id = parseInt(req.params.id);
  const { status } = req.body;
  const company = companies.find(c => c.id === id);
  if (company) {
    company.status = status;
    res.json({ message: "Status updated" });
  } else {
    res.status(404).json({ message: "Company not found" });
  }
});

app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
