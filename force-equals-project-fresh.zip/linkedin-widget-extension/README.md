# LinkedIn Widget Extension

## How to Run

1. Go to chrome://extensions
2. Enable Developer Mode
3. Click "Load Unpacked" and select the linkedin-widget-extension folder
4. Open any LinkedIn profile to see the widget
